import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_dimensions.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/date_helper.dart';
import '../../../core/utils/user_preferences.dart';
import '../../../widgets/loading_indicator.dart';
import '../../health_records/viewmodels/health_record_viewmodel.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _userName = 'User';

  @override
  void initState() {
    super.initState();
    _loadUserName();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HealthRecordViewModel>().refreshData();
    });
  }

  Future<void> _loadUserName() async {
    final name = await UserPreferences.getUserName();
    setState(() {
      _userName = name;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.dashboardTitle),
        
      ),
      body: Consumer<HealthRecordViewModel>(
        builder: (context, viewModel, child) {
          if (viewModel.isLoading && !viewModel.hasRecords) {
            return const LoadingIndicator(message: AppStrings.loadingRecords);
          }

          if (viewModel.hasError) {
            return _buildErrorState(viewModel);
          }

          return RefreshIndicator(
            onRefresh: () => viewModel.refreshData(),
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(AppDimensions.screenPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildWelcomeHeader(context),
                  const SizedBox(height: AppDimensions.spacingL),

                  if (viewModel.hasTodayData) ...[
                    Text(
                      AppStrings.todaySummary,
                      style: Theme.of(context).textTheme.displayMedium,
                    ),
                    const SizedBox(height: AppDimensions.spacingM),
                    _buildMetricsSummary(viewModel),
                    const SizedBox(height: AppDimensions.spacingL),
                  ] else ...[
                    _buildNoDataCard(),
                    const SizedBox(height: AppDimensions.spacingL),
                  ],

                  if (viewModel.hasRecords) ...[
                    _buildQuickStats(context, viewModel),
                    const SizedBox(height: AppDimensions.spacingL),
                  ],

                  _buildHealthTips(context),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildWelcomeHeader(BuildContext context) {
    final hour = DateTime.now().hour;
    String greeting = 'Good Morning';
    IconData greetingIcon = Icons.wb_sunny;

    if (hour >= 12 && hour < 17) {
      greeting = 'Good Afternoon';
      greetingIcon = Icons.wb_sunny_outlined;
    } else if (hour >= 17 && hour < 21) {
      greeting = 'Good Evening';
      greetingIcon = Icons.nights_stay;
    } else if (hour >= 21 || hour < 5) {
      greeting = 'Good Night';
      greetingIcon = Icons.bedtime;
    }

    return Container(
      padding: const EdgeInsets.all(AppDimensions.spacingL),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(AppDimensions.radiusL),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                greetingIcon,
                color: AppColors.textOnPrimary,
                size: AppDimensions.iconXL,
              ),
              const SizedBox(width: AppDimensions.spacingM),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      greeting,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: AppColors.textOnPrimary,
                          ),
                    ),
                    Text(
                      _userName,
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            color: AppColors.textOnPrimary,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.spacingS),
          Text(
            DateHelper.toFullDateString(DateTime.now()),
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textOnPrimary.withOpacity(0.9),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoDataCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.cardPadding),
        child: Column(
          children: [
            Icon(
              Icons.calendar_today,
              size: AppDimensions.iconXXL,
              color: AppColors.primary.withOpacity(0.5),
            ),
            const SizedBox(height: AppDimensions.spacingM),
            Text(
              'No data for today',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: AppDimensions.spacingS),
            Text(
              'Start tracking by adding your health metrics',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppColors.textSecondary,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  // NEW: Compact metrics summary that won't overflow
  Widget _buildMetricsSummary(HealthRecordViewModel viewModel) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.cardPadding),
        child: Column(
          children: [
            _buildMetricRow(
              icon: Icons.directions_walk,
              color: AppColors.stepsColor,
              label: 'Steps',
              value: viewModel.todaySteps.toString(),
              unit: 'steps',
            ),
            const Divider(height: 24),
            _buildMetricRow(
              icon: Icons.local_fire_department,
              color: AppColors.caloriesColor,
              label: 'Calories',
              value: viewModel.todayCalories.toString(),
              unit: 'kcal',
            ),
            const Divider(height: 24),
            _buildMetricRow(
              icon: Icons.water_drop,
              color: AppColors.waterColor,
              label: 'Water',
              value: viewModel.todayWater.toString(),
              unit: 'ml',
            ),
          ],
        ),
      ),
    );
  }

  // NEW: Helper method for metric rows
  Widget _buildMetricRow({
    required IconData icon,
    required Color color,
    required String label,
    required String value,
    required String unit,
  }) {
    return Row(
      children: [
        // Icon container
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: color,
            size: 28,
          ),
        ),
        const SizedBox(width: 16),
        // Label
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        // Value and unit
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              unit,
              style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickStats(BuildContext context, HealthRecordViewModel viewModel) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.cardPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.insights, color: AppColors.primary),
                const SizedBox(width: AppDimensions.spacingS),
                Text('Quick Stats', style: Theme.of(context).textTheme.titleLarge),
              ],
            ),
            const SizedBox(height: AppDimensions.spacingM),
            _buildStatRow(context, Icons.check_circle_outline, 'Total Records', '${viewModel.recordCount}'),
            const Divider(height: AppDimensions.spacingL),
            _buildStatRow(
              context,
              Icons.trending_up,
              'Steps Goal',
              viewModel.todaySteps >= 10000 ? 'Achieved! 🎉' : '${(viewModel.todaySteps / 10000 * 100).toInt()}%',
            ),
            const Divider(height: AppDimensions.spacingL),
            _buildStatRow(
              context,
              Icons.water_drop,
              'Water Goal',
              viewModel.todayWater >= 2000 ? 'Achieved! 💧' : '${(viewModel.todayWater / 2000 * 100).toInt()}%',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHealthTips(BuildContext context) {
    final tips = [
      {'icon': Icons.directions_walk, 'tip': 'Take 10,000 steps daily for better cardiovascular health', 'color': AppColors.stepsColor},
      {'icon': Icons.water_drop, 'tip': 'Drink at least 2 liters of water every day', 'color': AppColors.waterColor},
      {'icon': Icons.restaurant, 'tip': 'Eat a balanced diet with fruits and vegetables', 'color': AppColors.accent},
      {'icon': Icons.bedtime, 'tip': 'Get 7-8 hours of quality sleep each night', 'color': AppColors.primary},
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.cardPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.lightbulb, color: AppColors.accent),
                const SizedBox(width: AppDimensions.spacingS),
                Text('Health Tips', style: Theme.of(context).textTheme.titleLarge),
              ],
            ),
            const SizedBox(height: AppDimensions.spacingM),
            ...tips.map((tip) => Padding(
              padding: const EdgeInsets.only(bottom: AppDimensions.spacingM),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(tip['icon'] as IconData, color: tip['color'] as Color, size: 20),
                  const SizedBox(width: AppDimensions.spacingM),
                  Expanded(
                    child: Text(
                      tip['tip'] as String,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(BuildContext context, IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: AppDimensions.iconM, color: AppColors.textSecondary),
        const SizedBox(width: AppDimensions.spacingM),
        Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyLarge)),
        Text(value, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600, color: AppColors.primary)),
      ],
    );
  }

  Widget _buildErrorState(HealthRecordViewModel viewModel) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.screenPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: AppDimensions.iconXXL, color: AppColors.error),
            const SizedBox(height: AppDimensions.spacingM),
            Text(viewModel.errorMessage ?? AppStrings.errorGeneric, textAlign: TextAlign.center),
            const SizedBox(height: AppDimensions.spacingL),
            ElevatedButton(onPressed: () => viewModel.refreshData(), child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}